def oneself(x): return x


def to_oneself(): return oneself
